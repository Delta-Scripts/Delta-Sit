# Delta-Sit


Orignial - https://github.com/boostless/esx_sit

## Requirements

qb-core - https://github.com/qbcore-framework/qb-core

qb-target - https://github.com/BerkieBb/qb-target

polyzone - https://github.com/mkafrin/PolyZone

